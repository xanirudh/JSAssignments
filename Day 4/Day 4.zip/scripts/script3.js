let shoppingList = ['Apples', 'Chips','Tomato','Noodles'];

let shoppingBasket = ["Biscuit","Soap",...shoppingList,"Cream","Spices"];
console.log(`Shopping List:`)
console.log(shoppingList);
console.log(`Shopping Basket:`)
console.log(shoppingBasket);
