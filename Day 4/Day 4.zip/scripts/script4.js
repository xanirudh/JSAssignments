
let x,y,z,oper;
x=prompt(`Type first number`);
y=prompt(`Type second number (Leave blank in case of Square Root.)`);
oper=prompt(`Type an operator
+ : For Addition
- : For Substraction
* : For Multiplication
/ : For Division
% : For Percentage
! : For Square root`);

if(oper == "+"){
    z = parseFloat(x) + parseFloat(y);
}
if(oper == "-"){
    z = parseFloat(x) - parseFloat(y);
}
if(oper == "*"){
    z = parseFloat(x) * parseFloat(y);
}
if(oper == "/"){
    z = parseFloat(x) / parseFloat(y);
}
if(oper == "%"){
    z = parseFloat(x) / parseFloat(y) * 100;
}
if(oper == "!"){
    z = parseFloat(Math.sqrt(x));
}


console.log(z);

