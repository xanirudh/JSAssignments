function primeFactorsTo(max)
{
let arr  = [], i, j, prime = [];
for (i = 2; i <= max; ++i) 
{
   if (!arr[i]) 
   {
       prime.push(i);
       for (j = i << 1; j <= max; j += i) 
       {
          arr[j] = true;
       }
   }
}
return prime;
}
let n=prompt(`Prime numbers in interval 2 to n
please enter value of n`);
let x = primeFactorsTo(n);
let y = x.join(",");
console.log(y);