x = prompt(`Please enter a number greater than 100`);

if(typeof(x)=="object"){
    x=""

}else{
    while(x<=100 && x!=""){
        x = prompt(`Please enter a number greater than 100`);
    }
}
console.log(x);










