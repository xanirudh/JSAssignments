let input=prompt("Please enter your Sales figure:")

let commision=0;
let total=0;

if(input<=5000){
commision = 2 / 100 * input;
}
if(input>=5001 && input<=10000){
    commision = 5 / 100 * input;
}
if(input>=10001 && input<=20000){
    commision = 7 / 100 * input;
}
if(input>=20000){
    commision = 10 / 100 * input;
}

total = parseFloat(input) + parseFloat(commision);
console.log(`Your total commission is ${total} (Sales+Commission)`);