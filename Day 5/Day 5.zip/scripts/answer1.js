let input = prompt(`Please enter a positive number`);
input = parseInt(input);
let arr = [];

for( let i=0; i<=input; i++) {
arr.push(i);

}

console.log(arr);

let odd = arr.filter(el=>el%2!==0);

console.log(odd);

let oddcubes = arr.filter(el=>el%2!==0).map(el=>el**3);

console.log(oddcubes);