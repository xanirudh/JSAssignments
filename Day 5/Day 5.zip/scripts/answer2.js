class User {
    constructor(name, age, email){
        this.name = name;
        this.age = age;
        this.email = email;
        this.coins = 0;
        this.courses = [];
    }
    login(){
        console.log(`${this.name} has logged in`);
        return this;
    }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
}

class Moderator extends User{
addcoins(){
    this.coins++
    console.log(`${this.name} has ${this.coins} coins`);
    return this;
}
removecoins(){
    this.coins--
    console.log(`${this.name} has ${this.coins} coins`);
    return this;
}
}

class Admin extends Moderator{
    addcourse(user,course){
        user.courses.push(course);
        console.log(user);
    }
    removecourse(user,course){
        user.courses.filter(el=>el!=course);
        console.log(user);
    }

}



