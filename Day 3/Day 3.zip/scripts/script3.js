let input = prompt("Please enter your marks out of 100.");

let grade = 0;

if(input >= 75){
    grade = 'A'
}
else if(input >= 50){
    grade = 'B'
}
else if(input >= 25){
    grade = 'C'
}
else if(input >= 0){
    grade = 'D'
}

console.log(`Marks are ${input} and grade is ${grade}`);

//  Above program using Switch:

// switch (input) {
//     case input >= 75:
//         grade = 'A'
//         break;
//     case input >= 50:
//         grade = 'B'
//         break;
//     case input >= 25:
//         grade = 'C'
//         break;
//     case input >= 0:
//         grade = 'D'
//         break;
//     default:
//             console.log('Please enter valid marks.');

// }
// console.log(`Marks are ${input} and grade is ${grade}`);