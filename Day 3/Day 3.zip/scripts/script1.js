let number = prompt("Please enter a number");
let state = 0;
if(number % 2 == 0){
state = 'even';
}else{
    state = 'odd';
}
console.log(`The nummber entered is ${number} and Number is ${state}.`)