let input = prompt("Please enter your OS name with version.")

let arrinput = input.split("");
let version = arrinput.pop();
let os = arrinput.join("");

console.log(`The OS name is ${os} and the version is ${version}.`);